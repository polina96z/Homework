# car dealer
# The programm count the final cost of the car with all overpayments

print("Write down the cost of your new car and our programm will calculate the total cost with all extras")
car_cost = int(input("The car costs: $ "))

tax = car_cost * 0.13
registration = car_cost * 0.02
agency = 1000
delivery = 120

total = car_cost + tax + registration + agency + delivery

print("The final price is: $", total)

input("\n\nPress the key [Enter] to exit.")
