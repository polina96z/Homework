# new dishes creater
# The programm concatenates two words 

print("This programm is able to create a new dish especially for you.") 
print("Just remember two of your favourite dishes, and write them down!")
first_dish = input("Your first favourite dish is: ")
second_dish = input("Write down you second favourite meal here: ")

print("The new dish for you is:", first_dish + second_dish)

print("Now try to cook it!")

input("\n\nPress the key [Enter] to exit.")
