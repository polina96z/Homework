# word_problems.py
# Demonstrates mathematic operations

print("If a pergnant female hippo weighing 800 kg gives birth to a calf weighing 40 kg,")
print("but then eats 20 kg of food, how much will she weigh after all this?")
input("Press the key <Enter> to find out.")
print("800 - 400 + 20 =", 800 - 400 + 20)

print("\nIf a student, returning from a successfully passed exam, joyfully")
print("bought each of 6 friends 3 large sweets, then how many large sweets were bought in total?")
input("Press the key <Enter> to find out.")
print("6 * 3 =", 6 * 3)

print("\nIf at a restaurant you and your friends were bought all bill for 19$ (including tips),")
print("and you decided to chip in equally for four, then how much would you get from each?")
input("Press the key <Enter> to find out.")
print("19 / 4 =", 19 / 4)

print("\nIf four pirates find a chest containing exactly 107 gold coints and")
print("decide to divide the booty equally, how many whole coints will each get?")
input("Press the key <Enter> to find out.")
print("107 // 4 =", 107 // 4)

print("\nIf the same four pirates share the same 107 coints from the casket equally,")
print("how many coints will remain unclaimed?")
input("Press the key <Enter> to find out.")
print("107 % 4 =", 107 % 4)

print("7 / 3 =", 7 / 3)

input("\n\nPress the key <Enter> to exit.")

