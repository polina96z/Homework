# generous customer
# The programm counts the tips what are based on the bill

print("This programm will provide you with countings tips for our servise.",
     "You can leave 15 of 20 % to our waiters, write down the summ of your bill",
     "and choose the summ you would loke to leave")

summ = int(input("Write down the summ of your bill: $ "))

tips1 = summ * 0.15
tips2 = summ * 0.2

print(tips1)
print(tips2)

input("Choose the variant wich you would like to leave")