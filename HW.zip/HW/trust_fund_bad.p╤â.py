# trust_fund_bad.pу
# Demonstrates semantic error

print(
"""
                Rentier
The programm calculates your monthly expenses. You need to know these statistics
son that you don't run out of money and you don't have to look for a job.
Enter the amounts of expenses for all items listed below. You are rich,
so do not terifle, write the amonts in dollars, without cents.
"""
)

car = input("'Lamborgini' car maintenance: $")
rent = input("Rent a luxury arartment in Mannattan: $")
jet = ("Rent an aircraft: $")
gifts = ("Gifts: $")
food = ("Lunch and dinner in restaurants: $")
staff = ("Salary of servants (butlet, cook, driver, secretary): $") 
guru = input("Salary of personal psychoanalyst: $")
games = ("Computer games: $")

total = car + rent + jet + gifts + food + staff + guru + games
print("\nTotal: $, end")
print(total)

input("\n\nPress the key [Enter] to exit.")

